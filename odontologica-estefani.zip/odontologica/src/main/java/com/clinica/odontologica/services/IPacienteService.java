package com.clinica.odontologica.services;

import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.models.Paciente;
import com.clinica.odontologica.models.PacienteDto;

import java.util.Set;

public interface IPacienteService {

    Paciente crearPaciente(PacienteDto pacienteDto) throws BadRequestException;
    PacienteDto leerPaciente(Long id) throws BadRequestException;
    void modificarPaciente(PacienteDto pacienteDto) throws BadRequestException;
    void eliminarPaciente(Long id);
    Set<PacienteDto> getPacientes();
}
