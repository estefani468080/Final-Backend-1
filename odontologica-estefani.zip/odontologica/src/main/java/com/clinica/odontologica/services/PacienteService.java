package com.clinica.odontologica.services;

import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.exceptions.GlobalExceptions;
import com.clinica.odontologica.models.Paciente;
import com.clinica.odontologica.models.PacienteDto;
import com.clinica.odontologica.repository.IPacienteRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;


@Service
public class PacienteService extends GlobalExceptions implements IPacienteService{

    @Autowired
    private IPacienteRepository pacienteRepository;

    @Autowired
    ObjectMapper mapper;

    public Paciente crearPaciente(PacienteDto pacienteDto) throws BadRequestException {
        if(pacienteDto.getNombre() == "")
            throw new BadRequestException("El Paciente debe contener un nombre");
        if(pacienteDto.getApellido() == "")
            throw new BadRequestException("El Paciente debe contener un apellido");
        if(pacienteDto.getDni() == null)
            throw new BadRequestException("El Paciente debe contener un DNI");
        if(pacienteDto.getFechaAlta() == null)
            throw new BadRequestException("El Paciente debe contener una fecha de alta");

        Paciente paciente = mapper.convertValue(pacienteDto, Paciente.class);
        return pacienteRepository.save(paciente);
    }

    @Override
    public PacienteDto leerPaciente(Long id) {
        Optional<Paciente> paciente = pacienteRepository.findById(id);
        PacienteDto pacienteDto = null;
        if(paciente.isPresent())
            pacienteDto = mapper.convertValue(paciente, PacienteDto.class);
        return pacienteDto;
    }

    @Override
    public void modificarPaciente(PacienteDto pacienteDto) throws BadRequestException {
        if(pacienteDto.getNombre() == "")
            throw new BadRequestException("El Paciente debe contener un nombre");
        if(pacienteDto.getApellido() == "")
            throw new BadRequestException("El Paciente debe contener un apellido");
        if(pacienteDto.getDni() == null)
            throw new BadRequestException("El Paciente debe contener un DNI");
        if(pacienteDto.getFechaAlta() == null)
            throw new BadRequestException("El Paciente debe contener una fecha de alta");

        Paciente paciente = mapper.convertValue(pacienteDto, Paciente.class);
        pacienteRepository.save(paciente);
    }

    @Override
    public void eliminarPaciente(Long id) {
        pacienteRepository.deleteById(id);
    }

    @Override
    public Set<PacienteDto> getPacientes() {
        List<Paciente> pacientes =pacienteRepository.findAll();
        Set<PacienteDto> pacienteDtos = new HashSet<>();
        for (Paciente paciente: pacientes){
            pacienteDtos.add(mapper.convertValue(paciente, PacienteDto.class));
        }
        return pacienteDtos;
    }
}
