package com.clinica.odontologica.services;

import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.exceptions.GlobalExceptions;
import com.clinica.odontologica.models.Turno;
import com.clinica.odontologica.models.TurnoDto;
import com.clinica.odontologica.repository.ITurnoRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class TurnoService extends GlobalExceptions implements ITurnoService{

    @Autowired
    private ITurnoRepository turnoRepository;

    @Autowired
    ObjectMapper mapper;

    @Override
    public void crearTurno(TurnoDto turnoDto) throws BadRequestException {
        if(turnoDto.getOdontologo().getId() == null)
            throw new BadRequestException("El Turno debe contener un odontólogo");
        if(turnoDto.getPaciente().getId() == null)
            throw new BadRequestException("El Turno debe contener un paciente");
        if(turnoDto.getFechaHora() == null)
            throw new BadRequestException("El Turno debe contener una fecha");

        Turno turno = mapper.convertValue(turnoDto, Turno.class);
        turnoRepository.save(turno);

    }

    @Override
    public TurnoDto leerTurno(Long id){
        Optional<Turno> turno = turnoRepository.findById(id);
        TurnoDto turnoDto = null;
        if (turno.isPresent())
            turnoDto = mapper.convertValue(turno, TurnoDto.class);
        return turnoDto;
    }

    @Override
    public void modificarTurno(TurnoDto turnoDto) throws BadRequestException {
        if(turnoDto.getOdontologo() == null)
            throw new BadRequestException("El Turno debe contener un odontólogo");
        if(turnoDto.getPaciente() == null)
            throw new BadRequestException("El Turno debe contener un paciente");
        if(turnoDto.getFechaHora() == null)
            throw new BadRequestException("El Turno debe contener una fecha");

        Turno turno = mapper.convertValue(turnoDto, Turno.class);
        turnoRepository.save(turno);
    }

    @Override
    public void eliminarTurno(Long id) {
        turnoRepository.deleteById(id);
    }

    @Override
    public Set<TurnoDto> getTurnos() {
        List<Turno> turnos = turnoRepository.findAll();
        Set<TurnoDto> turnoDtos = new HashSet<>();
        for (Turno turno : turnos) {
            turnoDtos.add(mapper.convertValue(turno, TurnoDto.class));
        }
        return turnoDtos;
    }
}
