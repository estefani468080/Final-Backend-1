package com.clinica.odontologica.services;

import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.models.TurnoDto;

import java.util.Set;

public interface ITurnoService {

    void crearTurno(TurnoDto turnoDto) throws BadRequestException;
    TurnoDto leerTurno(Long id) throws BadRequestException;
    void modificarTurno(TurnoDto turnoDto) throws BadRequestException;
    void eliminarTurno(Long id);
    Set<TurnoDto> getTurnos();

}
