package com.clinica.odontologica.controllers;


import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.models.PacienteDto;
import com.clinica.odontologica.services.IPacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    @Autowired
    IPacienteService pacienteService;

    @PostMapping
    public ResponseEntity<?> crearPaciente(@RequestBody PacienteDto pacienteDto) throws BadRequestException {
        pacienteService.crearPaciente(pacienteDto);
        return ResponseEntity.ok(HttpStatus.OK);

    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarPaciente(@RequestBody PacienteDto pacienteDto) throws BadRequestException {
        ResponseEntity<?> response = null;

        if (pacienteDto.getId() != null && pacienteService.leerPaciente(pacienteDto.getId()) != null)
            pacienteService.modificarPaciente(pacienteDto);
        response = ResponseEntity.ok(HttpStatus.OK);

        return response;
    }

    @GetMapping("/{id}")
    public PacienteDto getPaciente(@PathVariable Long id) throws BadRequestException {
        return pacienteService.leerPaciente(id);
    }

    @GetMapping
    public Set<PacienteDto> getPacientesTodos(){
        return pacienteService.getPacientes();
    }

    @DeleteMapping("{id}")
    public ResponseEntity<?> deletePaciente(@PathVariable Long id){
        pacienteService.eliminarPaciente(id);
        return ResponseEntity.ok(HttpStatus.OK);
    }
}
