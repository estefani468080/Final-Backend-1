package com.clinica.odontologica.controllers;

import com.clinica.odontologica.services.IOdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class PageController {
    @Autowired
    IOdontologoService odontologoService;

    @GetMapping("/inicio")
    public String inicio(Model model) {
        model.addAttribute("activo", "inicio");
        return "inicio";
    }

    @GetMapping("/index")
    public String index(Model model) {
        model.addAttribute("activo", "inicio");
        return "index";
    }

    @GetMapping("/pagina/odontologos")
    public String odontologos(Model model) {
        model.addAttribute("titulo", "Odontólogos");
        return "odontologos";
    }

    @GetMapping("/pagina/pacientes")
    public String pacientes(Model model) {
        model.addAttribute("titulo", "Pacientes");
        return "pacientes";
    }

    @GetMapping("/pagina/turnos")
    public String turnos(Model model) {
        model.addAttribute("titulo", "Turnos");
        return "turnos";
    }
}
