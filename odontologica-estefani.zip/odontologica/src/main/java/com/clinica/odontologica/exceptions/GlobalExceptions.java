package com.clinica.odontologica.exceptions;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptions {
    private static final Logger logger = Logger.getLogger(GlobalExceptions.class);

    @ExceptionHandler({BadRequestException.class})
    public ResponseEntity<?> procesarErrorBadRequest(BadRequestException ex) {
        File log4jfile = new File("./src/logging/config/log4j.properties");
        PropertyConfigurator.configure(log4jfile.getAbsolutePath());

        String error = ex.getMessage()+ " capturado desde la clase... "+this.getClass().getName()+" de manera global";
        logger.error(error);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("error", ex.getMessage());
        map.put("status", 400);

        return new ResponseEntity<Object>(map,HttpStatus.BAD_REQUEST);
    }
}
