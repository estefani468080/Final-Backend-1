package com.clinica.odontologica.services;

public enum AppUsuarioRole {
    USER,ADMIN
}