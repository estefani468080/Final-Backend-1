package com.clinica.odontologica.services;

import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.exceptions.GlobalExceptions;
import com.clinica.odontologica.repository.IOdontologoRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.clinica.odontologica.models.Odontologo;
import com.clinica.odontologica.models.OdontologoDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class OdontologoService extends GlobalExceptions implements IOdontologoService{

    @Autowired
    private IOdontologoRepository odontologoRepository;

    @Autowired
    ObjectMapper mapper;

    @Override
    public Odontologo crearOdontologo(OdontologoDto odontologoDto) throws BadRequestException {
        if(odontologoDto.getNombre() == "")
            throw new BadRequestException("El Odontólogo debe contener un nombre");
        if(odontologoDto.getApellido() == "")
            throw new BadRequestException("El Odontólogo debe contener un apellido");
        if(odontologoDto.getMatricula() == null)
            throw new BadRequestException("El Odontólogo debe contener una matrícula");

        Odontologo odontologo = mapper.convertValue(odontologoDto, Odontologo.class);
        return odontologoRepository.save(odontologo);
    }

    @Override
    public OdontologoDto leerOdontologo(Long id){

        Optional<Odontologo> odontologo = odontologoRepository.findById(id);
        OdontologoDto odontologoDto = null;
        if(odontologo.isPresent())
            odontologoDto = mapper.convertValue(odontologo, OdontologoDto.class);
        return odontologoDto;
    }

    @Override
    public void modificarOdontologo(OdontologoDto odontologoDto) throws BadRequestException {
        if(odontologoDto.getNombre() == "")
            throw new BadRequestException("El Odontólogo debe contener un nombre");
        if(odontologoDto.getApellido() == "")
            throw new BadRequestException("El Odontólogo debe contener un apellido");
        if(odontologoDto.getMatricula() == null)
            throw new BadRequestException("El Odontólogo debe contener una matrícula");

        Odontologo odontologo = mapper.convertValue(odontologoDto, Odontologo.class);
        odontologoRepository.save(odontologo);
    }

    @Override
    public void eliminarOdontologo(Long id) {
        odontologoRepository.deleteById(id);
    }

    @Override
    public Set<OdontologoDto> getOdontologos() {
        List<Odontologo> odontologos =odontologoRepository.findAll();
        Set<OdontologoDto> odontologoDtos = new HashSet<>();
        for (Odontologo odontologo: odontologos){
            odontologoDtos.add(mapper.convertValue(odontologo, OdontologoDto.class));
        }
        return odontologoDtos;
    }
}
