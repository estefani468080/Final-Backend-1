package com.clinica.odontologica.models;

public enum AppUserRole {
    USER,ADMIN
}
