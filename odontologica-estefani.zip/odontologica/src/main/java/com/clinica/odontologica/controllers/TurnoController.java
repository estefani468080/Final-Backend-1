package com.clinica.odontologica.controllers;


import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.models.TurnoDto;
import com.clinica.odontologica.services.ITurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/turnos")
public class TurnoController {
    @Autowired
    ITurnoService turnoService;

    @PostMapping
    public ResponseEntity<?> crearTurno(@RequestBody TurnoDto turnoDto) throws BadRequestException {
        turnoService.crearTurno(turnoDto);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarTurno(@RequestBody TurnoDto turnoDto) throws BadRequestException {
        ResponseEntity<?> response = null;

        if (turnoDto.getId() != null && turnoService.leerTurno(turnoDto.getId()) != null)
            turnoService.modificarTurno(turnoDto);
        response = ResponseEntity.ok(HttpStatus.OK);

        return response;
    }

    @GetMapping("/{id}")
    public TurnoDto getTurno(@PathVariable Long id) throws BadRequestException{
        return turnoService.leerTurno(id);
    }

    @GetMapping
    public Set<TurnoDto> getTurnosTodos(){
        return turnoService.getTurnos();
    }

    @DeleteMapping("{id}")
    public ResponseEntity<?> deleteTurno(@PathVariable Long id){
        turnoService.eliminarTurno(id);
        return ResponseEntity.ok(HttpStatus.OK);
    }
}