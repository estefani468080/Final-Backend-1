package com.clinica.odontologica.services;

import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.models.Odontologo;
import com.clinica.odontologica.models.OdontologoDto;

import java.util.Set;

public interface IOdontologoService {

    Odontologo crearOdontologo(OdontologoDto odontologoDto) throws BadRequestException;
    OdontologoDto leerOdontologo(Long id) throws BadRequestException;
    void modificarOdontologo(OdontologoDto odontologoDto) throws BadRequestException;
    void eliminarOdontologo(Long id);
    Set<OdontologoDto> getOdontologos();
}
