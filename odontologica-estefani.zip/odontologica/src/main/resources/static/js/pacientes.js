$( document ).ready(function() {
    let type = 'crear';
    let idEditando;
    const urlPacientes = "http://localhost:8080/pacientes/";

    function cargarPacientesPeticion(){
        console.log("Cargando Pacientes");
        fetch(urlPacientes)
          .then((response) => response.json())
          .then((data) => cargarPacientes(data));
    }

    function cargarPacientes(pacientes) {
       const tablaPacientes = $("#pacientesTBody");
       tablaPacientes.html("");
       pacientes.forEach((paciente) => {
          console.log(paciente);
          tablaPacientes.append(`
            <tr>
                <th scope="row">${paciente.id}</th>
                <td>${paciente.nombre}</td>
                <td>${paciente.apellido}</td>
                <td>${paciente.dni}</td>
                <td>${paciente.fechaAlta}</td>
                <td>${paciente['domicilio']['calle']}</td>
                <td>${paciente['domicilio']['numero']}</td>
                <td>${paciente['domicilio']['localidad']}</td>
                <td>${paciente['domicilio']['provincia']}</td>
                <td>
                    <button class="btn btn-warning align-middle d-inline-flex" id="btn-editar-paciente" data-id="${paciente.id}"><span class="material-icons md-18">edit</span></button>
                    <button class="btn btn-danger align-middle d-inline-flex" id="btn-eliminar-confirmar-paciente" data-id="${paciente.id}"><span class="material-icons md-18">delete</span></button>
                </td>
            </tr>
          `);
       });
    }

    cargarPacientesPeticion();

    $(document).on("click", "#btn-crear-paciente", function(){
        $("#errorOcurrido").addClass("d-none");
        $("#mensajeRespuesta").addClass("d-none");
        console.log("CREAR");
        type = 'crear';
        $("#tituloModalLabel").html("Crear Paciente");
        $("#nombre").val("");
        $("#apellido").val("");
        $("#dni").val("");
        $("#calle").val("");
        $("#numero").val("");
        $("#localidad").val("");
        $("#provincia").val("");
        $("#idDomicilio").val("");
        $("#fecha").val("");
        $('#modalPaciente').modal('show');
    });

    $(document).on("click", "#btn-guardar-paciente", function(){
        $("#errorOcurrido").addClass("d-none");
        console.log("GUARDAR");
        const nombre = $("#nombre");
        const apellido = $("#apellido");
        const dni = $("#dni");
        const calle = $("#calle");
        const numero = $("#numero");
        const localidad = $("#localidad");
        const provincia = $("#provincia");
        const idDomicilio = $("#idDomicilio");
        const fecha = $("#fecha");

        const formData = {
          nombre: nombre.val(),
          apellido: apellido.val(),
          dni: dni.val(),
          fechaAlta: fecha.val(),
          domicilio: {
            calle: calle.val(),
            numero: numero.val(),
            localidad: localidad.val(),
            provincia: provincia.val(),
          }
        };
        let idComplemento = "";

        if(type=='editar'){
            idComplemento = idEditando;
            formData["id"] = idEditando;
            formData["domicilio"]["id"] = idDomicilio.val()
        }

        const settings = {
            method: type=='crear' ? "POST" : "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(formData),
        };

        fetch(urlPacientes + idComplemento, settings)
              .then( (response) => {
                  if( response.status == 400 ){
                      response.json().then(function(object) {
                          $("#errorOcurrido").removeClass("d-none");
                          $("#errorOcurrido").html(object["error"]);
                      })
                      throw new Error("error");
                  }
                  return response.json();
              })
              .then(() => {
                  $("#mensajeRespuesta").html("Se han guardado los datos satisfactoriamente");
                  $("#mensajeRespuesta").removeClass("d-none");

                   nombre.val("");
                   apellido.val("");
                   dni.val("");
                   calle.val("");
                   numero.val("");
                   localidad.val("");
                   provincia.val("");
                   idDomicilio.val("");
                   fecha.val("");

                   cargarPacientesPeticion();
                   $('#modalPaciente').modal('hide');
              })
              .catch(() => {
              })
              .finally(() => {

              })
    });

    function llenarParametros(data){
        console.log(data);
        type = 'editar';
        $("#tituloModalLabel").html("Editar Paciente");
        $("#nombre").val(data['nombre']);
        $("#apellido").val(data['apellido']);
        $("#dni").val(data['dni']);
        $("#calle").val(data['domicilio']['calle']);
        $("#numero").val(data['domicilio']['numero']);
        $("#localidad").val(data['domicilio']['localidad']);
        $("#provincia").val(data['domicilio']['provincia']);
        $("#idDomicilio").val(data['domicilio']['id']);
        console.log("Fecha: ", data['fechaAlta']);
        $("#fecha").val(data['fechaAlta']);
        idEditando = data['id'];

        $('#modalPaciente').modal('show');
    }

    $(document).on("click", "#btn-editar-paciente", function(){
        $("#errorOcurrido").addClass("d-none");
        $("#mensajeRespuesta").addClass("d-none");

        const id = $(this).attr("data-id");
        console.log("Editar: ", id);

        fetch(urlPacientes + id)
                    .then((response) => response.json())
                    .then((data) => llenarParametros(data) );
    });

    function eliminarPaciente(id){
        const settings = {
            method: "DELETE",
        };
        fetch(urlPacientes + id, settings)
            .then((response) => response.json())
            .then((data) =>  cargarPacientesPeticion() );
    }

    $(document).on("click", "#btn-eliminar-confirmar-paciente", function(){
        $("#mensajeRespuesta").addClass("d-none");
        $("#btn-eliminar-paciente").attr("data-id", $(this).attr("data-id"));
        $('#eliminarModal').modal('show');
    });

    $(document).on("click", "#btn-eliminar-paciente", function(){
        const id = $(this).attr("data-id");
        console.log("Eliminar: ", id);

        eliminarPaciente(id);
        $('#eliminarModal').modal('hide');
        $("#mensajeRespuesta").html("Se ha eliminado el Paciente");
        $("#mensajeRespuesta").removeClass("d-none");
    });
});