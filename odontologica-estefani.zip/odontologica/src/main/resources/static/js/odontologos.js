$( document ).ready(function() {
    let type = 'crear';
    let idEditando;
    const urlOdontologos = "http://localhost:8080/odontologos/";

    function cargarOdontologosPeticion(){
        console.log("Cargando Odontologos");
        fetch(urlOdontologos)
          .then((response) => response.json())
          .then((data) => cargarOdontologos(data));
    }

    function cargarOdontologos(odontologos) {
       const tablaOdontologos = $("#odontologosTBody");
       tablaOdontologos.html("");
       odontologos.forEach((odontologo) => {
          console.log(odontologo);
          tablaOdontologos.append(`
            <tr>
                <th scope="row">${odontologo.id}</th>
                <td>${odontologo.nombre}</td>
                <td>${odontologo.apellido}</td>
                <td>${odontologo.matricula}</td>
                <td>
                    <button class="btn btn-warning align-middle d-inline-flex" id="btn-editar-odontologo" data-id="${odontologo.id}"><span class="material-icons md-18">edit</span></button>
                    <button class="btn btn-danger align-middle d-inline-flex" id="btn-eliminar-confirmar-odontologo" data-id="${odontologo.id}"><span class="material-icons md-18">delete</span></button>
                </td>
            </tr>
          `);
       });
    }

    cargarOdontologosPeticion();

    $(document).on("click", "#btn-crear-odontologo", function(){
        $("#errorOcurrido").addClass("d-none");
        $("#mensajeRespuesta").addClass("d-none");
        console.log("CREAR");
        type = 'crear';
        $("#tituloModalLabel").html("Crear Odontólogo");
        $("#nombre").val("");
        $("#apellido").val("");
        $("#matricula").val("");
        $('#modalOdontologo').modal('show');
    });

    $(document).on("click", "#btn-guardar-odontologo", function(){
        $("#errorOcurrido").addClass("d-none");
        console.log("GUARDAR");
        const nombre = $("#nombre");
        const apellido = $("#apellido");
        const matricula = $("#matricula");

        const formData = {
          nombre: nombre.val(),
          apellido: apellido.val(),
          matricula: matricula.val(),
        };
        let idComplemento = "";

        if(type=='editar'){
            idComplemento = idEditando;
            formData["id"] = idEditando;
        }

        const settings = {
            method: type=='crear' ? "POST" : "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(formData),
        };

        fetch(urlOdontologos + idComplemento, settings)
              .then( (response) => {
                if( response.status == 400 ){
                    response.json().then(function(object) {
                        $("#errorOcurrido").removeClass("d-none");
                        $("#errorOcurrido").html(object["error"]);
                    })
                    throw new Error("error");
                }
                return response.json();
              })
              .then((result) => {
                 $("#mensajeRespuesta").html("Se han guardado los datos satisfactoriamente");
                 $("#mensajeRespuesta").removeClass("d-none");

                 cargarOdontologosPeticion();
                 $('#modalOdontologo').modal('hide');

                 nombre.val("");
                 apellido.val("");
                 matricula.val("");
              })
              .catch(() => {
              })
              .finally(() => {
              })
    });

    function llenarParametros(data){
        console.log(data);
        type = 'editar';
        $("#tituloModalLabel").html("Editar Odontólogo");
        $("#nombre").val(data['nombre']);
        $("#apellido").val(data['apellido']);
        $("#matricula").val(data['matricula']);
        idEditando = data['id'];

        $('#modalOdontologo').modal('show');
    }

    $(document).on("click", "#btn-editar-odontologo", function(){
        $("#mensajeRespuesta").addClass("d-none");
        $("#errorOcurrido").addClass("d-none");

        const id = $(this).attr("data-id");
        console.log("Editar: ", id);

        fetch(urlOdontologos + id)
                    .then((response) => response.json())
                    .then((data) => llenarParametros(data) );
    });

    function eliminarOdontologo(id){
        const settings = {
            method: "DELETE",
        };
        fetch(urlOdontologos + id, settings)
            .then((response) => response.json())
            .then((data) =>  cargarOdontologosPeticion() );
    }

    $(document).on("click", "#btn-eliminar-confirmar-odontologo", function(){
        $("#mensajeRespuesta").addClass("d-none");
        $("#btn-eliminar-odontologo").attr("data-id", $(this).attr("data-id"));
        $('#eliminarModal').modal('show');
    });

    $(document).on("click", "#btn-eliminar-odontologo", function(){
        const id = $(this).attr("data-id");
        console.log("Eliminar: ", id);

        eliminarOdontologo(id);
        $('#eliminarModal').modal('hide');
        $("#mensajeRespuesta").html("Se ha eliminado el Odontologo");
        $("#mensajeRespuesta").removeClass("d-none");
    });

});