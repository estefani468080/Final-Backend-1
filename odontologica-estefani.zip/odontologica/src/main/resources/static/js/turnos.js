$( document ).ready(function() {
    let type = 'crear';
    let idEditando;
    const urlApi = "http://localhost:8080/";
    const urlTurnos = urlApi + "turnos/";
    const urlOdontologos = urlApi + "odontologos/";
    const urlPacientes = urlApi + "pacientes/";

    function cargarOdontologosPeticion(){
        console.log("Cargando Odontólogos");
        fetch(urlOdontologos)
          .then((response) => response.json())
          .then((data) => cargarOdontologos(data));
    }

    function cargarOdontologos(odontologos) {
        const tablaOdontologos = $("#odontologo");
        tablaOdontologos.html("<option selected value=''>Seleccionar Odontólogo</option>");
        odontologos.forEach((odontologo) => {
           tablaOdontologos.append(`
             <option value="${odontologo['id']}">${odontologo['nombre']}</option>
           `);
        });
     }

    function cargarPacientesPeticion(){
        console.log("Cargando Pacientes");
        fetch(urlPacientes)
          .then((response) => response.json())
          .then((data) => cargarPacientes(data));
    }

    function cargarPacientes(pacientes) {
        const tablaPacientes = $("#paciente");
        tablaPacientes.html("<option selected value=''>Seleccionar Paciente</option>");
        pacientes.forEach((paciente) => {
           console.log(paciente);
           tablaPacientes.append(`
             <option value="${paciente['id']}">${paciente['nombre']}</option>
           `);
        });
     }

    function cargarTurnosPeticion(){
        console.log("Cargando Turnos");
        fetch(urlTurnos)
          .then((response) => response.json())
          .then((data) => cargarTurnos(data));
    }

    function cargarTurnos(turnos) {
       const tablaTurnos = $("#turnosTBody");
       tablaTurnos.html("");
       turnos.forEach((turno) => {
          console.log(turno);
          tablaTurnos.append(`
            <tr>
                <th scope="row">${turno.id}</th>
                <td>${turno['paciente']['id']}</td>
                <td>${turno['paciente']['nombre']}</td>
                <td>${turno['odontologo']['id']}</td>
                <td>${turno['odontologo']['nombre']}</td>
                <td>${turno.fechaHora}</td>
                <td>
                    <button class="btn btn-warning align-middle d-inline-flex" id="btn-editar-turno" data-id="${turno.id}"><span class="material-icons md-18">edit</span></button>
                    <button class="btn btn-danger align-middle d-inline-flex" id="btn-eliminar-confirmar-turno" data-id="${turno.id}"><span class="material-icons md-18">delete</span></button>
                </td>
            </tr>
          `);
       });
    }

    cargarTurnosPeticion();
    cargarOdontologosPeticion();
    cargarPacientesPeticion();

    $(document).on("click", "#btn-crear-turno", function(){
        $("#errorOcurrido").addClass("d-none");
        $("#mensajeRespuesta").addClass("d-none");
        console.log("CREAR");
        type = 'crear';
        $("#tituloModalLabel").html("Crear Turno");
        $("#paciente").val("");
        $("#odontologo").val("");
        $("#fechaHora").val("");
        $('#modalTurno').modal('show');
    });

    $(document).on("click", "#btn-guardar-turno", function(){
        $("#errorOcurrido").addClass("d-none");
        console.log("GUARDAR");
        const paciente = $("#paciente");
        const odontologo = $("#odontologo");
        const fechaHora = $("#fecha");

        const formData = {
          paciente: {
            id: paciente.val()
          },
          odontologo: {
            id: odontologo.val()
          },
          fechaHora: fechaHora.val(),
        };
        let idComplemento = "";

        if(type=='editar'){
            idComplemento = idEditando;
            formData["id"] = idEditando;
        }

        const settings = {
            method: type=='crear' ? "POST" : "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(formData),
        };

        fetch(urlTurnos + idComplemento, settings)
              .then( (response) => {
                    if( response.status == 400 ){
                        response.json().then(function(object) {
                            $("#errorOcurrido").removeClass("d-none");
                            $("#errorOcurrido").html(object["error"]);
                        })
                        throw new Error("error");
                    }
                    return response.json();
              })
              .then(() => {
                $("#mensajeRespuesta").html("Se han guardado los datos satisfactoriamente");
                $("#mensajeRespuesta").removeClass("d-none");

                paciente.val("");
                odontologo.val("");
                fechaHora.val("");

                cargarTurnosPeticion();
                $('#modalTurno').modal('hide');
              })
              .catch(() => {
              })
              .finally(() => {

              })
    });

    function llenarParametros(data){
        console.log(data);
        type = 'editar';
        $("#tituloModalLabel").html("Editar Turno");
        $("#paciente").val(data['paciente']['id']);
        $("#odontologo").val(data['odontologo']['id']);

        $("#fecha").val(data['fechaHora']);
        idEditando = data['id'];

        $('#modalTurno').modal('show');
    }

    $(document).on("click", "#btn-editar-turno", function(){
        $("#errorOcurrido").addClass("d-none");
        $("#mensajeRespuesta").addClass("d-none");

        const id = $(this).attr("data-id");
        console.log("Editar: ", id);

        fetch(urlTurnos + id)
                    .then((response) => response.json())
                    .then((data) => llenarParametros(data) );
    });

    function eliminarTurno(id){
        const settings = {
            method: "DELETE",
        };
        fetch(urlTurnos + id, settings)
            .then((response) => response.json())
            .then((data) =>  cargarTurnosPeticion() );
    }

    $(document).on("click", "#btn-eliminar-confirmar-turno", function(){
        $("#mensajeRespuesta").addClass("d-none");
        $("#btn-eliminar-turno").attr("data-id", $(this).attr("data-id"));
        $('#eliminarModal').modal('show');
    });

    $(document).on("click", "#btn-eliminar-turno", function(){
        const id = $(this).attr("data-id");
        console.log("Eliminar: ", id);

        eliminarTurno(id);
        $('#eliminarModal').modal('hide');
        $("#mensajeRespuesta").html("Se ha eliminado el Turno");
        $("#mensajeRespuesta").removeClass("d-none");
    });

});