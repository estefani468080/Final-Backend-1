package com.clinica.odontologica;

import com.clinica.odontologica.exceptions.BadRequestException;
import com.clinica.odontologica.models.Odontologo;
import com.clinica.odontologica.models.OdontologoDto;
import com.clinica.odontologica.services.OdontologoService;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


import java.util.List;
import java.util.Set;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringRunner.class)
@SpringBootTest
public class OdontologoServiceTests {
    @Autowired
    private OdontologoService odontologoService;


    public void cargarDataSet() throws BadRequestException {
        this.odontologoService.crearOdontologo(new OdontologoDto("Santiago", "Paz", 3455647));
    }

    @Test
    public void agregarOdontologo() throws BadRequestException {
        this.cargarDataSet();
        Odontologo odontologo = odontologoService.crearOdontologo(new OdontologoDto("Juan", "Ramirez", 348971960));
        Assert.assertTrue(odontologo.getId() != null);
    }

    @Test
    public void eliminarOdontologoTest() throws BadRequestException {
        long longnum = 1;
        odontologoService.eliminarOdontologo(longnum);
        Assert.assertEquals(null, odontologoService.leerOdontologo(longnum));
    }

    @Test
    public void traerTodos() {
        Set<OdontologoDto> odontologos = odontologoService.getOdontologos();
        Assert.assertTrue(!odontologos.isEmpty());
        Assert.assertTrue(odontologos.size() == 1);
        System.out.println(odontologos);
    }

}
